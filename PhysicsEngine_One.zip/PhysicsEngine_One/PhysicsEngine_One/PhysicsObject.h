#pragma once
#include <glm/glm.hpp>
class PhysicsObject
{
	// What do physics objects have in common:
	// Vec3 Position | Mass | vec3 Velocity
	//
public:
	PhysicsObject() {};
	// Pass in default mass
	PhysicsObject(float mass);

	void SetPosition(const glm::vec3& newPosition)
		glm::vec3 GetPosition() const;

	void SetMass(float mass);
	float GetMass() const;
	void SetVelocity(const glm::vec3& newVelocity);
	glm::vec3 GetVelocity() const;

	~PhysicsObject() {};

	void AddForce(const glm::vec3 force);
	void Update(float deltaTime);

private:
	glm::vec3 m_position;
	float	  m_mass;
	glm::vec3 m_velocity;
	glm::vec3 m_force;	// apply every frame, to continuely affect object.
};
