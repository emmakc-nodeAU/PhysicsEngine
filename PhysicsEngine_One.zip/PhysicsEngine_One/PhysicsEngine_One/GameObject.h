#pragma once

class GameObject
{
public:
	GameObject() {};
	~GameObject() {};

	virtual void Update(float deltaTime) {};

	virtual void Render() {};

};