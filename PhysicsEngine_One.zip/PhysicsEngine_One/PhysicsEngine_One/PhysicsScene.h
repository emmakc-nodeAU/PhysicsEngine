#pragma once
#include <set>
class PhysicsObject;
class PhysicsScene;

class PhysicsScene
{
public:
	PhysicsScene();
	~PhysicsScene();

	void Add(PhysicsObject* newObject);
	void Remove(PhysicsObject* objectToRemove);

	void Update(float deltaTime);	
private:
	std::set<PhysicsObject*> m_physicsObjects;

};