#include "PhysicsObject.h"

PhysicsObject::PhysicsObject()
	: PhysicsObject(1.0f)
{
}

PhysicsObject::PhysicsObject(float mass)
	: m_mass(1.0f)
	, m_position(0.0f, 0.0f, 0.0f)
	, m_velocity(0.0f, 0.0f, 0.0f)
	, m_force(0.0f,0.0f,0.0f)
{
}
PhysicsObject::~PhysicsObject()
{
}

void PhysicsObject::SetPosition(const glm::vec3& newPosition)
{
	m_position = newPosition;
}

glm::vec3 PhysicsObject::GetPosition() const
{
	return m_position;
}

void PhysicsObject::SetMass(float mass)
{
	m_mass = newMass;
}

float PhysicsObject::GetMass() const
{
	return m_mass;
}

void PhysicsObject::SetVelocity(const glm::vec3 & newVelocity)
{
	m_velocity = newVelocity;
}

glm::vec3 PhysicsObject::GetVelocity() const
{
	return m_velocity;
}

void PhysicsObject::AddForce(const glm::vec3 force)
{
	m_force += force;	// accumulate all forces in a frame, in update each force will be used to calucaute acceleration.
	// once acceralteion found, then cal velocity and fro mvelocity we calc position.
}

void PhysicsObject::Update(float deltaTime)
{
	// Calucate getting things to move.
	// first cal the acceleration
	glm::vec3 acceleration = m_force / m_mass
		// cal velocity
	m_velocity = m_velocity + acceleration * deltaTime;
	m_position = m_position + m_velocity * deltaTime;
		//end of each frame, reset force to zero
		m_force = glm::vec3(0.0f, 0.0f, 0.0f);
}
